--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

SET statement_timeout = 0;
SET lock_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SET check_function_bodies = false;
SET client_min_messages = warning;

SET search_path = ap, pg_catalog;

ALTER TABLE ONLY ap.usuario DROP CONSTRAINT usuariorol;
ALTER TABLE ONLY ap.agente DROP CONSTRAINT usuarioid;
ALTER TABLE ONLY ap.evaluacion DROP CONSTRAINT usuarioid;
ALTER TABLE ONLY ap.proyecto DROP CONSTRAINT tipoproyectoid;
ALTER TABLE ONLY ap.convocatoria DROP CONSTRAINT tipoproyectoid;
ALTER TABLE ONLY ap.proyecto DROP CONSTRAINT tipofinanciamientoid;
ALTER TABLE ONLY ap.convocatoria DROP CONSTRAINT tipofinanciamientoid;
ALTER TABLE ONLY ap.pregunta DROP CONSTRAINT tipoevaluacionid;
ALTER TABLE ONLY ap.evaluacion DROP CONSTRAINT tipoevaluacionid;
ALTER TABLE ONLY ap.agente DROP CONSTRAINT tipodocumentoid;
ALTER TABLE ONLY ap.comitente DROP CONSTRAINT tipocomitenteid;
ALTER TABLE ONLY ap.tareaprogreso DROP CONSTRAINT tareaid;
ALTER TABLE ONLY ap.tarea_agente DROP CONSTRAINT tareaid;
ALTER TABLE ONLY ap.comitente DROP CONSTRAINT sectorid;
ALTER TABLE ONLY ap.presupuesto_rubroitem DROP CONSTRAINT rubroid;
ALTER TABLE ONLY ap.presupuesto_rubro DROP CONSTRAINT rubroid;
ALTER TABLE ONLY ap.etapa DROP CONSTRAINT proyectoid;
ALTER TABLE ONLY ap.presupuesto DROP CONSTRAINT proyectoid;
ALTER TABLE ONLY ap.evaluacion DROP CONSTRAINT proyectoid;
ALTER TABLE ONLY ap.archivoproyecto DROP CONSTRAINT proyectoid;
ALTER TABLE ONLY ap.presupuesto_rubroitem DROP CONSTRAINT presupuestoid;
ALTER TABLE ONLY ap.presupuesto_rubro DROP CONSTRAINT presupuestoid;
ALTER TABLE ONLY ap.evaluacion_pregunta DROP CONSTRAINT preguntaid;
ALTER TABLE ONLY ap.proyecto DROP CONSTRAINT fuentefinanciamientoid;
ALTER TABLE ONLY ap.evaluacion_pregunta DROP CONSTRAINT evaluacionid;
ALTER TABLE ONLY ap.tarea DROP CONSTRAINT etapaid;
ALTER TABLE ONLY ap.proyecto DROP CONSTRAINT estadoproyectoid;
ALTER TABLE ONLY ap.agente DROP CONSTRAINT dependenciaid;
ALTER TABLE ONLY ap.proyecto DROP CONSTRAINT convocatoriaid;
ALTER TABLE ONLY ap.proyecto DROP CONSTRAINT comitenteid;
ALTER TABLE ONLY ap.proyecto DROP CONSTRAINT beneficiarioid;
ALTER TABLE ONLY ap.proyecto DROP CONSTRAINT avanceproyectoid;
ALTER TABLE ONLY ap.tarea_agente DROP CONSTRAINT agenteid;
ALTER TABLE ONLY ap.proyecto DROP CONSTRAINT agenteid;
ALTER TABLE ONLY ap.usuario DROP CONSTRAINT usuarioid;
ALTER TABLE ONLY ap.usuario DROP CONSTRAINT username;
ALTER TABLE ONLY ap.tipoproyecto DROP CONSTRAINT tipoproyectoid;
ALTER TABLE ONLY ap.tipofinanciamiento DROP CONSTRAINT tipofinanciamiento_pkey;
ALTER TABLE ONLY ap.tipoevaluacion DROP CONSTRAINT tipoevaluacionid;
ALTER TABLE ONLY ap.tipocomitente DROP CONSTRAINT tipoentidadid;
ALTER TABLE ONLY ap.tipodocumento DROP CONSTRAINT tipodocumentoid;
ALTER TABLE ONLY ap.tareaprogreso DROP CONSTRAINT tareaprogreso_pkey;
ALTER TABLE ONLY ap.tarea DROP CONSTRAINT tarea_pkey;
ALTER TABLE ONLY ap.tarea_agente DROP CONSTRAINT tarea_agente_pkey;
ALTER TABLE ONLY ap.sector DROP CONSTRAINT sector_pkey;
ALTER TABLE ONLY ap.rubro DROP CONSTRAINT rubroid;
ALTER TABLE ONLY ap.perfil DROP CONSTRAINT rolid;
ALTER TABLE ONLY ap.proyecto DROP CONSTRAINT proyectoid;
ALTER TABLE ONLY ap.proyecto_agente DROP CONSTRAINT proyecto_agente_pkey;
ALTER TABLE ONLY ap.presupuesto DROP CONSTRAINT presupuestoid;
ALTER TABLE ONLY ap.presupuesto_rubroitem DROP CONSTRAINT presupuesto_rubroitem_pkey;
ALTER TABLE ONLY ap.presupuesto_rubro DROP CONSTRAINT presu_rubro;
ALTER TABLE ONLY ap.pregunta DROP CONSTRAINT preguntaevaluacion_pkey;
ALTER TABLE ONLY ap.agente DROP CONSTRAINT id;
ALTER TABLE ONLY ap.fuentefinanciamiento DROP CONSTRAINT fuentefinanciamiento_pkey;
ALTER TABLE ONLY ap.evaluacion_pregunta DROP CONSTRAINT evaluacion_pregunta_pkey;
ALTER TABLE ONLY ap.evaluacion DROP CONSTRAINT evaluacion_pkey;
ALTER TABLE ONLY ap.etapa DROP CONSTRAINT etapa_pkey;
ALTER TABLE ONLY ap.estadoproyecto DROP CONSTRAINT estadoproyecto_pkey;
ALTER TABLE ONLY ap.comitente DROP CONSTRAINT entidadbenefiaciariaid;
ALTER TABLE ONLY ap.dependencia DROP CONSTRAINT dependenciaid;
ALTER TABLE ONLY ap.convocatoria DROP CONSTRAINT convocatoriaid;
ALTER TABLE ONLY ap.configuracion DROP CONSTRAINT configuracion_pkey;
ALTER TABLE ONLY ap.beneficiario DROP CONSTRAINT beneficiario_pkey;
ALTER TABLE ONLY ap.avanceproyecto DROP CONSTRAINT avance_proyecto_pkey;
ALTER TABLE ONLY ap.archivoproyecto DROP CONSTRAINT archivoproyecto_pkey;
ALTER TABLE ap.usuario ALTER COLUMN usuarioid DROP DEFAULT;
ALTER TABLE ap.tipoproyecto ALTER COLUMN id DROP DEFAULT;
ALTER TABLE ap.tipofinanciamiento ALTER COLUMN id DROP DEFAULT;
ALTER TABLE ap.tipoevaluacion ALTER COLUMN tipoevaluacionid DROP DEFAULT;
ALTER TABLE ap.tipodocumento ALTER COLUMN tipodocumentoid DROP DEFAULT;
ALTER TABLE ap.tipocomitente ALTER COLUMN id DROP DEFAULT;
ALTER TABLE ap.tareaprogreso ALTER COLUMN id DROP DEFAULT;
ALTER TABLE ap.tarea ALTER COLUMN id DROP DEFAULT;
ALTER TABLE ap.sector ALTER COLUMN id DROP DEFAULT;
ALTER TABLE ap.rubro ALTER COLUMN id DROP DEFAULT;
ALTER TABLE ap.proyecto ALTER COLUMN id DROP DEFAULT;
ALTER TABLE ap.presupuesto ALTER COLUMN id DROP DEFAULT;
ALTER TABLE ap.pregunta ALTER COLUMN id DROP DEFAULT;
ALTER TABLE ap.perfil ALTER COLUMN rolid DROP DEFAULT;
ALTER TABLE ap.fuentefinanciamiento ALTER COLUMN id DROP DEFAULT;
ALTER TABLE ap.evaluacion ALTER COLUMN id DROP DEFAULT;
ALTER TABLE ap.etapa ALTER COLUMN id DROP DEFAULT;
ALTER TABLE ap.estadoproyecto ALTER COLUMN id DROP DEFAULT;
ALTER TABLE ap.dependencia ALTER COLUMN id DROP DEFAULT;
ALTER TABLE ap.convocatoria ALTER COLUMN id DROP DEFAULT;
ALTER TABLE ap.configuracion ALTER COLUMN id DROP DEFAULT;
ALTER TABLE ap.comitente ALTER COLUMN id DROP DEFAULT;
ALTER TABLE ap.beneficiario ALTER COLUMN id DROP DEFAULT;
ALTER TABLE ap.avanceproyecto ALTER COLUMN id DROP DEFAULT;
ALTER TABLE ap.archivoproyecto ALTER COLUMN id DROP DEFAULT;
ALTER TABLE ap.agente ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE ap.usuario_usuarioid_seq;
DROP TABLE ap.usuario;
DROP SEQUENCE ap.tipoproyecto_id_seq;
DROP TABLE ap.tipoproyecto;
DROP SEQUENCE ap.tipofinanciamiento_id_seq;
DROP TABLE ap.tipofinanciamiento;
DROP SEQUENCE ap.tipoevaluacion_tipoevaluacionid_seq;
DROP TABLE ap.tipoevaluacion;
DROP SEQUENCE ap.tipodocumento_tipodocumentoid_seq;
DROP TABLE ap.tipodocumento;
DROP SEQUENCE ap.tipocomitente_id_seq;
DROP TABLE ap.tipocomitente;
DROP SEQUENCE ap.tareaprogreso_id_seq;
DROP TABLE ap.tareaprogreso;
DROP SEQUENCE ap.tarea_id_seq;
DROP TABLE ap.tarea_agente;
DROP TABLE ap.tarea;
DROP SEQUENCE ap.sector_id_seq;
DROP TABLE ap.sector;
DROP SEQUENCE ap.rubro_id_seq;
DROP TABLE ap.rubro;
DROP SEQUENCE ap.proyecto_id_seq;
DROP TABLE ap.proyecto_agente;
DROP TABLE ap.proyecto;
DROP TABLE ap.presupuesto_rubroitem;
DROP TABLE ap.presupuesto_rubro;
DROP SEQUENCE ap.presupuesto_id_seq;
DROP TABLE ap.presupuesto;
DROP SEQUENCE ap.pregunta_id_seq;
DROP TABLE ap.pregunta;
DROP SEQUENCE ap.perfil_rolid_seq;
DROP TABLE ap.perfil;
DROP SEQUENCE ap.hibernate_sequence;
DROP SEQUENCE ap.fuentefinanciamiento_id_seq;
DROP TABLE ap.fuentefinanciamiento;
DROP TABLE ap.evaluacion_pregunta;
DROP SEQUENCE ap.evaluacion_id_seq;
DROP TABLE ap.evaluacion;
DROP SEQUENCE ap.etapa_id_seq;
DROP TABLE ap.etapa;
DROP SEQUENCE ap.estadoproyecto_id_seq;
DROP TABLE ap.estadoproyecto;
DROP SEQUENCE ap.dependencia_id_seq;
DROP TABLE ap.dependencia;
DROP SEQUENCE ap.convocatoria_id_seq;
DROP TABLE ap.convocatoria;
DROP SEQUENCE ap.configuracion_id_seq;
DROP TABLE ap.configuracion;
DROP SEQUENCE ap.comitente_id_seq;
DROP TABLE ap.comitente;
DROP SEQUENCE ap.beneficiario_id_seq;
DROP TABLE ap.beneficiario;
DROP SEQUENCE ap.avance_proyecto_id_seq;
DROP TABLE ap.avanceproyecto;
DROP SEQUENCE ap.archivoproyecto_id_seq;
DROP TABLE ap.archivoproyecto;
DROP SEQUENCE ap.agente_id_seq;
DROP TABLE ap.agente;
DROP EXTENSION plpgsql;
DROP SCHEMA public;
DROP SCHEMA ap;
--
-- Name: ap; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA ap;


ALTER SCHEMA ap OWNER TO postgres;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: postgres
--

CREATE SCHEMA public;


ALTER SCHEMA public OWNER TO postgres;

--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: postgres
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: plpgsql; Type: EXTENSION; Schema: -; Owner: 
--

CREATE EXTENSION IF NOT EXISTS plpgsql WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION plpgsql; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION plpgsql IS 'PL/pgSQL procedural language';


SET search_path = ap, pg_catalog;

SET default_tablespace = '';

SET default_with_oids = false;

--
-- Name: agente; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE agente (
    apellido character varying(25),
    nombres character varying(35),
    tipodocumentoid integer,
    numerodocumento character varying(15),
    telefono character varying(25),
    celular character varying(25),
    email character varying(60),
    otroemail character varying(60),
    profesion character varying(100),
    id integer NOT NULL,
    domicilio text,
    dependenciaid integer,
    usuarioid integer,
    especialidad character varying(50)
);


ALTER TABLE ap.agente OWNER TO postgres;

--
-- Name: agente_id_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE agente_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.agente_id_seq OWNER TO postgres;

--
-- Name: agente_id_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE agente_id_seq OWNED BY agente.id;


--
-- Name: archivoproyecto; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE archivoproyecto (
    link text,
    proyectoid integer,
    nombre character varying(50),
    archivo bytea,
    id integer NOT NULL
);


ALTER TABLE ap.archivoproyecto OWNER TO postgres;

--
-- Name: archivoproyecto_id_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE archivoproyecto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.archivoproyecto_id_seq OWNER TO postgres;

--
-- Name: archivoproyecto_id_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE archivoproyecto_id_seq OWNED BY archivoproyecto.id;


--
-- Name: avanceproyecto; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE avanceproyecto (
    id integer NOT NULL,
    avance character varying(100)
);


ALTER TABLE ap.avanceproyecto OWNER TO postgres;

--
-- Name: avance_proyecto_id_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE avance_proyecto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.avance_proyecto_id_seq OWNER TO postgres;

--
-- Name: avance_proyecto_id_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE avance_proyecto_id_seq OWNED BY avanceproyecto.id;


--
-- Name: beneficiario; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE beneficiario (
    id integer NOT NULL,
    beneficiario character varying(35)
);


ALTER TABLE ap.beneficiario OWNER TO postgres;

--
-- Name: beneficiario_id_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE beneficiario_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.beneficiario_id_seq OWNER TO postgres;

--
-- Name: beneficiario_id_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE beneficiario_id_seq OWNED BY beneficiario.id;


--
-- Name: comitente; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE comitente (
    id integer NOT NULL,
    razonsocial character varying(150),
    cuit character varying(20),
    telefono character varying(25),
    email character varying(100),
    tipocomitenteid integer,
    contacto character varying(150),
    cargocontacto character varying(150),
    sectorid integer
);


ALTER TABLE ap.comitente OWNER TO postgres;

--
-- Name: comitente_id_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE comitente_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.comitente_id_seq OWNER TO postgres;

--
-- Name: comitente_id_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE comitente_id_seq OWNED BY comitente.id;


--
-- Name: configuracion; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE configuracion (
    id integer NOT NULL,
    clave character varying(200),
    valor text
);


ALTER TABLE ap.configuracion OWNER TO postgres;

--
-- Name: configuracion_id_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE configuracion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.configuracion_id_seq OWNER TO postgres;

--
-- Name: configuracion_id_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE configuracion_id_seq OWNED BY configuracion.id;


--
-- Name: convocatoria; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE convocatoria (
    id integer NOT NULL,
    convocatoria character varying(150),
    descripcion text,
    bases bytea,
    link text,
    formulario bytea,
    tipoproyectoid integer,
    fechapublicacion timestamp with time zone,
    fechainicio timestamp with time zone,
    fechacierre timestamp with time zone,
    tipofinanciamientoid integer,
    estado character(1),
    organismo text,
    beneficiario text,
    montofinanciamiento numeric(9,2)
);


ALTER TABLE ap.convocatoria OWNER TO postgres;

--
-- Name: convocatoria_id_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE convocatoria_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.convocatoria_id_seq OWNER TO postgres;

--
-- Name: convocatoria_id_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE convocatoria_id_seq OWNED BY convocatoria.id;


--
-- Name: dependencia; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE dependencia (
    id integer NOT NULL,
    dependencia text
);


ALTER TABLE ap.dependencia OWNER TO postgres;

--
-- Name: dependencia_id_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE dependencia_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.dependencia_id_seq OWNER TO postgres;

--
-- Name: dependencia_id_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE dependencia_id_seq OWNED BY dependencia.id;


--
-- Name: estadoproyecto; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE estadoproyecto (
    id integer NOT NULL,
    estado character varying(50),
    descripcion text,
    estadoabreviado character(3) NOT NULL,
    proyecto boolean
);


ALTER TABLE ap.estadoproyecto OWNER TO postgres;

--
-- Name: estadoproyecto_id_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE estadoproyecto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.estadoproyecto_id_seq OWNER TO postgres;

--
-- Name: estadoproyecto_id_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE estadoproyecto_id_seq OWNED BY estadoproyecto.id;


--
-- Name: etapa; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE etapa (
    id integer NOT NULL,
    etapa text,
    fechainicio timestamp with time zone,
    dias integer,
    estado character varying(30),
    proyectoid integer,
    fechafin timestamp with time zone
);


ALTER TABLE ap.etapa OWNER TO postgres;

--
-- Name: etapa_id_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE etapa_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.etapa_id_seq OWNER TO postgres;

--
-- Name: etapa_id_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE etapa_id_seq OWNED BY etapa.id;


--
-- Name: evaluacion; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE evaluacion (
    id integer NOT NULL,
    fecha timestamp with time zone,
    observacion text,
    usuarioid integer,
    proyectoid integer,
    tipoevaluacionid integer
);


ALTER TABLE ap.evaluacion OWNER TO postgres;

--
-- Name: evaluacion_id_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE evaluacion_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.evaluacion_id_seq OWNER TO postgres;

--
-- Name: evaluacion_id_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE evaluacion_id_seq OWNED BY evaluacion.id;


--
-- Name: evaluacion_pregunta; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE evaluacion_pregunta (
    evaluacionid integer NOT NULL,
    preguntaid integer NOT NULL,
    rating integer,
    observacion text,
    aprobado boolean,
    tipoevaluacionid integer
);


ALTER TABLE ap.evaluacion_pregunta OWNER TO postgres;

--
-- Name: fuentefinanciamiento; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE fuentefinanciamiento (
    id integer NOT NULL,
    fuentefinanciamiento text
);


ALTER TABLE ap.fuentefinanciamiento OWNER TO postgres;

--
-- Name: fuentefinanciamiento_id_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE fuentefinanciamiento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.fuentefinanciamiento_id_seq OWNER TO postgres;

--
-- Name: fuentefinanciamiento_id_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE fuentefinanciamiento_id_seq OWNED BY fuentefinanciamiento.id;


--
-- Name: hibernate_sequence; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE hibernate_sequence
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.hibernate_sequence OWNER TO postgres;

--
-- Name: perfil; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE perfil (
    rolid integer NOT NULL,
    rol character varying(30) NOT NULL
);


ALTER TABLE ap.perfil OWNER TO postgres;

--
-- Name: perfil_rolid_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE perfil_rolid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.perfil_rolid_seq OWNER TO postgres;

--
-- Name: perfil_rolid_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE perfil_rolid_seq OWNED BY perfil.rolid;


--
-- Name: pregunta; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE pregunta (
    id integer NOT NULL,
    pregunta text,
    proyecto boolean,
    tipoevaluacionid integer NOT NULL
);


ALTER TABLE ap.pregunta OWNER TO postgres;

--
-- Name: pregunta_id_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE pregunta_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.pregunta_id_seq OWNER TO postgres;

--
-- Name: pregunta_id_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE pregunta_id_seq OWNED BY pregunta.id;


--
-- Name: presupuesto; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE presupuesto (
    id integer NOT NULL,
    proyectoid integer,
    fecha timestamp without time zone,
    estado character(1)
);


ALTER TABLE ap.presupuesto OWNER TO postgres;

--
-- Name: presupuesto_id_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE presupuesto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.presupuesto_id_seq OWNER TO postgres;

--
-- Name: presupuesto_id_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE presupuesto_id_seq OWNED BY presupuesto.id;


--
-- Name: presupuesto_rubro; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE presupuesto_rubro (
    presupuestoid integer NOT NULL,
    rubroid integer NOT NULL,
    gastocomitente numeric(9,2),
    gastouniversidad numeric(9,2),
    estado character(1),
    gastoorganismo numeric(9,2),
    total numeric(12,2)
);


ALTER TABLE ap.presupuesto_rubro OWNER TO postgres;

--
-- Name: presupuesto_rubroitem; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE presupuesto_rubroitem (
    descripcion text,
    costounitario numeric(10,2),
    cantidad numeric(10,2),
    total numeric(10,2),
    rubroid integer NOT NULL,
    presupuestoid integer NOT NULL,
    aportecomitente numeric(10,2),
    aporteuniversidad numeric(10,2),
    aporteorganismo numeric(10,2)
);


ALTER TABLE ap.presupuesto_rubroitem OWNER TO postgres;

--
-- Name: proyecto; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE proyecto (
    comitenteid integer,
    convocatoriaid integer,
    nombre text,
    resumen text,
    documentacion bytea,
    observaciones text,
    duracion smallint,
    agenteid integer,
    tipoproyectoid integer,
    cudap character varying(30),
    fecha timestamp with time zone,
    id integer NOT NULL,
    beneficiarioid integer,
    tipofinanciamientoid integer,
    localizacion text,
    fuentefinanciamientoid integer,
    documentacionnombre character varying(200),
    avanceproyectoid integer,
    estadoproyectoid integer
);


ALTER TABLE ap.proyecto OWNER TO postgres;

--
-- Name: proyecto_agente; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE proyecto_agente (
    agenteid integer NOT NULL,
    proyectoid integer NOT NULL,
    funcionproyecto character varying(35)
);


ALTER TABLE ap.proyecto_agente OWNER TO postgres;

--
-- Name: proyecto_id_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE proyecto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.proyecto_id_seq OWNER TO postgres;

--
-- Name: proyecto_id_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE proyecto_id_seq OWNED BY proyecto.id;


--
-- Name: rubro; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE rubro (
    id integer NOT NULL,
    rubro character varying(60)
);


ALTER TABLE ap.rubro OWNER TO postgres;

--
-- Name: rubro_id_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE rubro_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.rubro_id_seq OWNER TO postgres;

--
-- Name: rubro_id_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE rubro_id_seq OWNED BY rubro.id;


--
-- Name: sector; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE sector (
    id integer NOT NULL,
    sector character varying(50)
);


ALTER TABLE ap.sector OWNER TO postgres;

--
-- Name: sector_id_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE sector_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.sector_id_seq OWNER TO postgres;

--
-- Name: sector_id_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE sector_id_seq OWNED BY sector.id;


--
-- Name: tarea; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE tarea (
    tarea text,
    prioridad character varying(15),
    fechacreacion timestamp with time zone,
    dias integer,
    descripcion text,
    fechamodificacion timestamp with time zone,
    fechainicio timestamp with time zone,
    fechafin timestamp with time zone,
    etapaid integer,
    id integer NOT NULL,
    estado integer
);


ALTER TABLE ap.tarea OWNER TO postgres;

--
-- Name: tarea_agente; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE tarea_agente (
    tareaid integer NOT NULL,
    agenteid integer NOT NULL,
    funcion character varying(50)
);


ALTER TABLE ap.tarea_agente OWNER TO postgres;

--
-- Name: tarea_id_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE tarea_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.tarea_id_seq OWNER TO postgres;

--
-- Name: tarea_id_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE tarea_id_seq OWNED BY tarea.id;


--
-- Name: tareaprogreso; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE tareaprogreso (
    id integer NOT NULL,
    fecha timestamp with time zone,
    progreso integer,
    estado character(1),
    tareaid integer
);


ALTER TABLE ap.tareaprogreso OWNER TO postgres;

--
-- Name: tareaprogreso_id_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE tareaprogreso_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.tareaprogreso_id_seq OWNER TO postgres;

--
-- Name: tareaprogreso_id_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE tareaprogreso_id_seq OWNED BY tareaprogreso.id;


--
-- Name: tipocomitente; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE tipocomitente (
    tipocomitente character varying,
    id integer NOT NULL
);


ALTER TABLE ap.tipocomitente OWNER TO postgres;

--
-- Name: tipocomitente_id_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE tipocomitente_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.tipocomitente_id_seq OWNER TO postgres;

--
-- Name: tipocomitente_id_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE tipocomitente_id_seq OWNED BY tipocomitente.id;


--
-- Name: tipodocumento; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE tipodocumento (
    tipodocumentoid integer NOT NULL,
    tipodocumento character varying NOT NULL
);


ALTER TABLE ap.tipodocumento OWNER TO postgres;

--
-- Name: tipodocumento_tipodocumentoid_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE tipodocumento_tipodocumentoid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.tipodocumento_tipodocumentoid_seq OWNER TO postgres;

--
-- Name: tipodocumento_tipodocumentoid_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE tipodocumento_tipodocumentoid_seq OWNED BY tipodocumento.tipodocumentoid;


--
-- Name: tipoevaluacion; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE tipoevaluacion (
    tipoevaluacionid integer NOT NULL,
    tipoevaluacion character varying(25) NOT NULL
);


ALTER TABLE ap.tipoevaluacion OWNER TO postgres;

--
-- Name: tipoevaluacion_tipoevaluacionid_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE tipoevaluacion_tipoevaluacionid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.tipoevaluacion_tipoevaluacionid_seq OWNER TO postgres;

--
-- Name: tipoevaluacion_tipoevaluacionid_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE tipoevaluacion_tipoevaluacionid_seq OWNED BY tipoevaluacion.tipoevaluacionid;


--
-- Name: tipofinanciamiento; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE tipofinanciamiento (
    id integer NOT NULL,
    tipofinanciamiento character varying(100)
);


ALTER TABLE ap.tipofinanciamiento OWNER TO postgres;

--
-- Name: tipofinanciamiento_id_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE tipofinanciamiento_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.tipofinanciamiento_id_seq OWNER TO postgres;

--
-- Name: tipofinanciamiento_id_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE tipofinanciamiento_id_seq OWNED BY tipofinanciamiento.id;


--
-- Name: tipoproyecto; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE tipoproyecto (
    id integer NOT NULL,
    tipo character varying(100)
);


ALTER TABLE ap.tipoproyecto OWNER TO postgres;

--
-- Name: tipoproyecto_id_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE tipoproyecto_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.tipoproyecto_id_seq OWNER TO postgres;

--
-- Name: tipoproyecto_id_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE tipoproyecto_id_seq OWNED BY tipoproyecto.id;


--
-- Name: usuario; Type: TABLE; Schema: ap; Owner: postgres; Tablespace: 
--

CREATE TABLE usuario (
    usuarioid integer NOT NULL,
    usuarionombre text,
    usuarioclave character varying(255),
    usuarioestado character(1) DEFAULT 'A'::bpchar NOT NULL,
    usuariorol integer NOT NULL,
    usuariofechaalta timestamp without time zone,
    usuariofechabaja timestamp without time zone,
    habilitacion text
);


ALTER TABLE ap.usuario OWNER TO postgres;

--
-- Name: usuario_usuarioid_seq; Type: SEQUENCE; Schema: ap; Owner: postgres
--

CREATE SEQUENCE usuario_usuarioid_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE ap.usuario_usuarioid_seq OWNER TO postgres;

--
-- Name: usuario_usuarioid_seq; Type: SEQUENCE OWNED BY; Schema: ap; Owner: postgres
--

ALTER SEQUENCE usuario_usuarioid_seq OWNED BY usuario.usuarioid;


--
-- Name: id; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY agente ALTER COLUMN id SET DEFAULT nextval('agente_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY archivoproyecto ALTER COLUMN id SET DEFAULT nextval('archivoproyecto_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY avanceproyecto ALTER COLUMN id SET DEFAULT nextval('avance_proyecto_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY beneficiario ALTER COLUMN id SET DEFAULT nextval('beneficiario_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY comitente ALTER COLUMN id SET DEFAULT nextval('comitente_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY configuracion ALTER COLUMN id SET DEFAULT nextval('configuracion_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY convocatoria ALTER COLUMN id SET DEFAULT nextval('convocatoria_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY dependencia ALTER COLUMN id SET DEFAULT nextval('dependencia_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY estadoproyecto ALTER COLUMN id SET DEFAULT nextval('estadoproyecto_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY etapa ALTER COLUMN id SET DEFAULT nextval('etapa_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY evaluacion ALTER COLUMN id SET DEFAULT nextval('evaluacion_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY fuentefinanciamiento ALTER COLUMN id SET DEFAULT nextval('fuentefinanciamiento_id_seq'::regclass);


--
-- Name: rolid; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY perfil ALTER COLUMN rolid SET DEFAULT nextval('perfil_rolid_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY pregunta ALTER COLUMN id SET DEFAULT nextval('pregunta_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY presupuesto ALTER COLUMN id SET DEFAULT nextval('presupuesto_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY proyecto ALTER COLUMN id SET DEFAULT nextval('proyecto_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY rubro ALTER COLUMN id SET DEFAULT nextval('rubro_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY sector ALTER COLUMN id SET DEFAULT nextval('sector_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY tarea ALTER COLUMN id SET DEFAULT nextval('tarea_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY tareaprogreso ALTER COLUMN id SET DEFAULT nextval('tareaprogreso_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY tipocomitente ALTER COLUMN id SET DEFAULT nextval('tipocomitente_id_seq'::regclass);


--
-- Name: tipodocumentoid; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY tipodocumento ALTER COLUMN tipodocumentoid SET DEFAULT nextval('tipodocumento_tipodocumentoid_seq'::regclass);


--
-- Name: tipoevaluacionid; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY tipoevaluacion ALTER COLUMN tipoevaluacionid SET DEFAULT nextval('tipoevaluacion_tipoevaluacionid_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY tipofinanciamiento ALTER COLUMN id SET DEFAULT nextval('tipofinanciamiento_id_seq'::regclass);


--
-- Name: id; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY tipoproyecto ALTER COLUMN id SET DEFAULT nextval('tipoproyecto_id_seq'::regclass);


--
-- Name: usuarioid; Type: DEFAULT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY usuario ALTER COLUMN usuarioid SET DEFAULT nextval('usuario_usuarioid_seq'::regclass);


--
-- Data for Name: agente; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2246.dat

--
-- Name: agente_id_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('agente_id_seq', 86, true);


--
-- Data for Name: archivoproyecto; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2248.dat

--
-- Name: archivoproyecto_id_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('archivoproyecto_id_seq', 9, true);


--
-- Name: avance_proyecto_id_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('avance_proyecto_id_seq', 4, true);


--
-- Data for Name: avanceproyecto; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2250.dat

--
-- Data for Name: beneficiario; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2252.dat

--
-- Name: beneficiario_id_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('beneficiario_id_seq', 4, true);


--
-- Data for Name: comitente; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2254.dat

--
-- Name: comitente_id_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('comitente_id_seq', 10, true);


--
-- Data for Name: configuracion; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2256.dat

--
-- Name: configuracion_id_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('configuracion_id_seq', 1, true);


--
-- Data for Name: convocatoria; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2258.dat

--
-- Name: convocatoria_id_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('convocatoria_id_seq', 9, true);


--
-- Data for Name: dependencia; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2260.dat

--
-- Name: dependencia_id_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('dependencia_id_seq', 8, true);


--
-- Data for Name: estadoproyecto; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2262.dat

--
-- Name: estadoproyecto_id_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('estadoproyecto_id_seq', 11, true);


--
-- Data for Name: etapa; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2264.dat

--
-- Name: etapa_id_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('etapa_id_seq', 25, true);


--
-- Data for Name: evaluacion; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2266.dat

--
-- Name: evaluacion_id_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('evaluacion_id_seq', 10, true);


--
-- Data for Name: evaluacion_pregunta; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2268.dat

--
-- Data for Name: fuentefinanciamiento; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2269.dat

--
-- Name: fuentefinanciamiento_id_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('fuentefinanciamiento_id_seq', 8, true);


--
-- Name: hibernate_sequence; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('hibernate_sequence', 1, false);


--
-- Data for Name: perfil; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2272.dat

--
-- Name: perfil_rolid_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('perfil_rolid_seq', 3, true);


--
-- Data for Name: pregunta; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2274.dat

--
-- Name: pregunta_id_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('pregunta_id_seq', 8, true);


--
-- Data for Name: presupuesto; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2276.dat

--
-- Name: presupuesto_id_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('presupuesto_id_seq', 73, true);


--
-- Data for Name: presupuesto_rubro; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2278.dat

--
-- Data for Name: presupuesto_rubroitem; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2279.dat

--
-- Data for Name: proyecto; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2280.dat

--
-- Data for Name: proyecto_agente; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2281.dat

--
-- Name: proyecto_id_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('proyecto_id_seq', 98, true);


--
-- Data for Name: rubro; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2283.dat

--
-- Name: rubro_id_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('rubro_id_seq', 10, true);


--
-- Data for Name: sector; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2285.dat

--
-- Name: sector_id_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('sector_id_seq', 2, true);


--
-- Data for Name: tarea; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2287.dat

--
-- Data for Name: tarea_agente; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2288.dat

--
-- Name: tarea_id_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('tarea_id_seq', 25, true);


--
-- Data for Name: tareaprogreso; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2290.dat

--
-- Name: tareaprogreso_id_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('tareaprogreso_id_seq', 1, false);


--
-- Data for Name: tipocomitente; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2292.dat

--
-- Name: tipocomitente_id_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('tipocomitente_id_seq', 2, true);


--
-- Data for Name: tipodocumento; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2294.dat

--
-- Name: tipodocumento_tipodocumentoid_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('tipodocumento_tipodocumentoid_seq', 4, true);


--
-- Data for Name: tipoevaluacion; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2303.dat

--
-- Name: tipoevaluacion_tipoevaluacionid_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('tipoevaluacion_tipoevaluacionid_seq', 3, true);


--
-- Data for Name: tipofinanciamiento; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2296.dat

--
-- Name: tipofinanciamiento_id_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('tipofinanciamiento_id_seq', 6, true);


--
-- Data for Name: tipoproyecto; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2298.dat

--
-- Name: tipoproyecto_id_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('tipoproyecto_id_seq', 2, true);


--
-- Data for Name: usuario; Type: TABLE DATA; Schema: ap; Owner: postgres
--

\i $$PATH$$/2300.dat

--
-- Name: usuario_usuarioid_seq; Type: SEQUENCE SET; Schema: ap; Owner: postgres
--

SELECT pg_catalog.setval('usuario_usuarioid_seq', 115, true);


--
-- Name: archivoproyecto_pkey; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY archivoproyecto
    ADD CONSTRAINT archivoproyecto_pkey PRIMARY KEY (id);


--
-- Name: avance_proyecto_pkey; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY avanceproyecto
    ADD CONSTRAINT avance_proyecto_pkey PRIMARY KEY (id);


--
-- Name: beneficiario_pkey; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY beneficiario
    ADD CONSTRAINT beneficiario_pkey PRIMARY KEY (id);


--
-- Name: configuracion_pkey; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY configuracion
    ADD CONSTRAINT configuracion_pkey PRIMARY KEY (id);


--
-- Name: convocatoriaid; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY convocatoria
    ADD CONSTRAINT convocatoriaid PRIMARY KEY (id);


--
-- Name: dependenciaid; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY dependencia
    ADD CONSTRAINT dependenciaid PRIMARY KEY (id);


--
-- Name: entidadbenefiaciariaid; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY comitente
    ADD CONSTRAINT entidadbenefiaciariaid PRIMARY KEY (id);


--
-- Name: estadoproyecto_pkey; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY estadoproyecto
    ADD CONSTRAINT estadoproyecto_pkey PRIMARY KEY (id);


--
-- Name: etapa_pkey; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY etapa
    ADD CONSTRAINT etapa_pkey PRIMARY KEY (id);


--
-- Name: evaluacion_pkey; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY evaluacion
    ADD CONSTRAINT evaluacion_pkey PRIMARY KEY (id);


--
-- Name: evaluacion_pregunta_pkey; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY evaluacion_pregunta
    ADD CONSTRAINT evaluacion_pregunta_pkey PRIMARY KEY (evaluacionid, preguntaid);


--
-- Name: fuentefinanciamiento_pkey; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY fuentefinanciamiento
    ADD CONSTRAINT fuentefinanciamiento_pkey PRIMARY KEY (id);


--
-- Name: id; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY agente
    ADD CONSTRAINT id PRIMARY KEY (id);


--
-- Name: preguntaevaluacion_pkey; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY pregunta
    ADD CONSTRAINT preguntaevaluacion_pkey PRIMARY KEY (id);


--
-- Name: presu_rubro; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY presupuesto_rubro
    ADD CONSTRAINT presu_rubro PRIMARY KEY (presupuestoid, rubroid);


--
-- Name: presupuesto_rubroitem_pkey; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY presupuesto_rubroitem
    ADD CONSTRAINT presupuesto_rubroitem_pkey PRIMARY KEY (presupuestoid, rubroid);


--
-- Name: presupuestoid; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY presupuesto
    ADD CONSTRAINT presupuestoid PRIMARY KEY (id);


--
-- Name: proyecto_agente_pkey; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY proyecto_agente
    ADD CONSTRAINT proyecto_agente_pkey PRIMARY KEY (agenteid, proyectoid);


--
-- Name: proyectoid; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY proyecto
    ADD CONSTRAINT proyectoid PRIMARY KEY (id);


--
-- Name: rolid; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY perfil
    ADD CONSTRAINT rolid PRIMARY KEY (rolid);


--
-- Name: rubroid; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY rubro
    ADD CONSTRAINT rubroid PRIMARY KEY (id);


--
-- Name: sector_pkey; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY sector
    ADD CONSTRAINT sector_pkey PRIMARY KEY (id);


--
-- Name: tarea_agente_pkey; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tarea_agente
    ADD CONSTRAINT tarea_agente_pkey PRIMARY KEY (tareaid, agenteid);


--
-- Name: tarea_pkey; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tarea
    ADD CONSTRAINT tarea_pkey PRIMARY KEY (id);


--
-- Name: tareaprogreso_pkey; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tareaprogreso
    ADD CONSTRAINT tareaprogreso_pkey PRIMARY KEY (id);


--
-- Name: tipodocumentoid; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tipodocumento
    ADD CONSTRAINT tipodocumentoid PRIMARY KEY (tipodocumentoid);


--
-- Name: tipoentidadid; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tipocomitente
    ADD CONSTRAINT tipoentidadid PRIMARY KEY (id);


--
-- Name: tipoevaluacionid; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tipoevaluacion
    ADD CONSTRAINT tipoevaluacionid PRIMARY KEY (tipoevaluacionid);


--
-- Name: tipofinanciamiento_pkey; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tipofinanciamiento
    ADD CONSTRAINT tipofinanciamiento_pkey PRIMARY KEY (id);


--
-- Name: tipoproyectoid; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY tipoproyecto
    ADD CONSTRAINT tipoproyectoid PRIMARY KEY (id);


--
-- Name: username; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY usuario
    ADD CONSTRAINT username UNIQUE (usuarionombre);


--
-- Name: usuarioid; Type: CONSTRAINT; Schema: ap; Owner: postgres; Tablespace: 
--

ALTER TABLE ONLY usuario
    ADD CONSTRAINT usuarioid PRIMARY KEY (usuarioid);


--
-- Name: agenteid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY proyecto
    ADD CONSTRAINT agenteid FOREIGN KEY (agenteid) REFERENCES agente(id);


--
-- Name: agenteid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY tarea_agente
    ADD CONSTRAINT agenteid FOREIGN KEY (agenteid) REFERENCES agente(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: avanceproyectoid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY proyecto
    ADD CONSTRAINT avanceproyectoid FOREIGN KEY (avanceproyectoid) REFERENCES avanceproyecto(id);


--
-- Name: beneficiarioid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY proyecto
    ADD CONSTRAINT beneficiarioid FOREIGN KEY (beneficiarioid) REFERENCES beneficiario(id);


--
-- Name: comitenteid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY proyecto
    ADD CONSTRAINT comitenteid FOREIGN KEY (comitenteid) REFERENCES comitente(id);


--
-- Name: convocatoriaid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY proyecto
    ADD CONSTRAINT convocatoriaid FOREIGN KEY (convocatoriaid) REFERENCES convocatoria(id);


--
-- Name: dependenciaid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY agente
    ADD CONSTRAINT dependenciaid FOREIGN KEY (dependenciaid) REFERENCES dependencia(id);


--
-- Name: estadoproyectoid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY proyecto
    ADD CONSTRAINT estadoproyectoid FOREIGN KEY (estadoproyectoid) REFERENCES estadoproyecto(id);


--
-- Name: etapaid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY tarea
    ADD CONSTRAINT etapaid FOREIGN KEY (etapaid) REFERENCES etapa(id);


--
-- Name: evaluacionid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY evaluacion_pregunta
    ADD CONSTRAINT evaluacionid FOREIGN KEY (evaluacionid) REFERENCES evaluacion(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: fuentefinanciamientoid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY proyecto
    ADD CONSTRAINT fuentefinanciamientoid FOREIGN KEY (fuentefinanciamientoid) REFERENCES fuentefinanciamiento(id);


--
-- Name: preguntaid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY evaluacion_pregunta
    ADD CONSTRAINT preguntaid FOREIGN KEY (preguntaid) REFERENCES pregunta(id);


--
-- Name: presupuestoid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY presupuesto_rubro
    ADD CONSTRAINT presupuestoid FOREIGN KEY (presupuestoid) REFERENCES presupuesto(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: presupuestoid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY presupuesto_rubroitem
    ADD CONSTRAINT presupuestoid FOREIGN KEY (presupuestoid) REFERENCES presupuesto(id);


--
-- Name: proyectoid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY archivoproyecto
    ADD CONSTRAINT proyectoid FOREIGN KEY (proyectoid) REFERENCES proyecto(id);


--
-- Name: proyectoid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY evaluacion
    ADD CONSTRAINT proyectoid FOREIGN KEY (proyectoid) REFERENCES proyecto(id);


--
-- Name: proyectoid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY presupuesto
    ADD CONSTRAINT proyectoid FOREIGN KEY (proyectoid) REFERENCES proyecto(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: proyectoid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY etapa
    ADD CONSTRAINT proyectoid FOREIGN KEY (proyectoid) REFERENCES proyecto(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: rubroid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY presupuesto_rubro
    ADD CONSTRAINT rubroid FOREIGN KEY (rubroid) REFERENCES rubro(id);


--
-- Name: rubroid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY presupuesto_rubroitem
    ADD CONSTRAINT rubroid FOREIGN KEY (rubroid) REFERENCES rubro(id);


--
-- Name: sectorid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY comitente
    ADD CONSTRAINT sectorid FOREIGN KEY (sectorid) REFERENCES sector(id);


--
-- Name: tareaid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY tarea_agente
    ADD CONSTRAINT tareaid FOREIGN KEY (tareaid) REFERENCES tarea(id);


--
-- Name: tareaid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY tareaprogreso
    ADD CONSTRAINT tareaid FOREIGN KEY (tareaid) REFERENCES tarea(id);


--
-- Name: tipocomitenteid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY comitente
    ADD CONSTRAINT tipocomitenteid FOREIGN KEY (tipocomitenteid) REFERENCES tipocomitente(id);


--
-- Name: tipodocumentoid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY agente
    ADD CONSTRAINT tipodocumentoid FOREIGN KEY (tipodocumentoid) REFERENCES tipodocumento(tipodocumentoid);


--
-- Name: tipoevaluacionid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY evaluacion
    ADD CONSTRAINT tipoevaluacionid FOREIGN KEY (tipoevaluacionid) REFERENCES tipoevaluacion(tipoevaluacionid);


--
-- Name: tipoevaluacionid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY pregunta
    ADD CONSTRAINT tipoevaluacionid FOREIGN KEY (tipoevaluacionid) REFERENCES tipoevaluacion(tipoevaluacionid);


--
-- Name: tipofinanciamientoid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY convocatoria
    ADD CONSTRAINT tipofinanciamientoid FOREIGN KEY (tipofinanciamientoid) REFERENCES tipofinanciamiento(id);


--
-- Name: tipofinanciamientoid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY proyecto
    ADD CONSTRAINT tipofinanciamientoid FOREIGN KEY (tipofinanciamientoid) REFERENCES tipofinanciamiento(id);


--
-- Name: tipoproyectoid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY convocatoria
    ADD CONSTRAINT tipoproyectoid FOREIGN KEY (tipoproyectoid) REFERENCES tipoproyecto(id);


--
-- Name: tipoproyectoid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY proyecto
    ADD CONSTRAINT tipoproyectoid FOREIGN KEY (tipoproyectoid) REFERENCES tipoproyecto(id);


--
-- Name: usuarioid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY evaluacion
    ADD CONSTRAINT usuarioid FOREIGN KEY (usuarioid) REFERENCES usuario(usuarioid);


--
-- Name: usuarioid; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY agente
    ADD CONSTRAINT usuarioid FOREIGN KEY (usuarioid) REFERENCES usuario(usuarioid) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: usuariorol; Type: FK CONSTRAINT; Schema: ap; Owner: postgres
--

ALTER TABLE ONLY usuario
    ADD CONSTRAINT usuariorol FOREIGN KEY (usuariorol) REFERENCES perfil(rolid);


--
-- Name: public; Type: ACL; Schema: -; Owner: postgres
--

REVOKE ALL ON SCHEMA public FROM PUBLIC;
REVOKE ALL ON SCHEMA public FROM postgres;
GRANT ALL ON SCHEMA public TO postgres;
GRANT ALL ON SCHEMA public TO PUBLIC;


--
-- PostgreSQL database dump complete
--

